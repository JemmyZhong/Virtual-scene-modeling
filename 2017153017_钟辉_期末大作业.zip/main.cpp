﻿#include "Angel.h"
#include "mesh.h"
#include <mmsystem.h>
#include "Mesh_Painter.h"
#include<cmath>
using namespace std;
#pragma comment(lib, "Winmm.lib")
//#pragma comment(lib, "glew32.lib")
//#pragma comment(lib, "FreeImage.lib")
#define R 800.0	//天空盒子平移增量
#define gap 100.0	//天空盒子竖直平移增量
struct Window
{ //指定窗口口大小
	int width = 800;
	int height = 800;
};
Window window;
typedef Angel::vec4 point4;
typedef Angel::vec4 color4;

// 相机参数
float radius = 6.8; //全局视角下的观察距离
float fr = 0.8;		//第一人称距离下的观察距离
float rotateAngle = -92;
float upAngle = 43.0;
vec4 at = vec4(0, 0, 0, 1);
vec4 eye = vec4(0, 0, 0, 1);
int att = 0;

//机器人参数
enum robot
{
	TORSO,
	HEAD,
	LEFT_UPPER_ARM,
	RIGHT_UPPER_ARM,
	LEFT_UPPER_LEG,
	RIGHT_UPPER_LEG,
	NUM_COMPONENTS
};
//机器人的身体部件参数
#define HEAD_HEIGHT 0.20
#define HEAD_WIDTH 0.20
#define HEAD_DEPTH 0.14

#define TORSO_HEIGHT 0.30
#define TORSO_WIDTH 0.20
#define TORSO_DEPTH 0.10

#define UPPER_ARM_HEIGHT 0.30
#define UPPER_ARM_WIDTH 0.10
#define UPPER_ARM_DEPTH 0.10

#define UPPER_LEG_HEIGHT 0.35
#define UPPER_LEG_WIDTH 0.10
#define UPPER_LEG_DEPTH 0.10

float degree = 0; //运动时的手臂或者脚的摆幅
My_Mesh *robot[10];
//狐狸的对象s
My_Mesh *fox;
//光照的参数
vec3 lightPos = vec3(400, 400, 400);

std::vector<My_Mesh *> my_meshs;
Mesh_Painter *mp_ = new Mesh_Painter;
;

void init()
{ //调用深度测试
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glClearColor(0.9, 0.9, 0.9, 1.0);
}

void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	float x2, y2, z2, x1, y1, z1;
	float tx, ty, tz; //当前夹角
	//att = 0时,运动物体为机器人
	//att = 1时,运动物体为狐狸
	//att = 2时机器人的第一视角
	if (att == 0)
	{	//获取机器人躯干的位置信息
		robot[TORSO]->get_translate(x2, y2, z2);
		//cout<<x2<<y2<<z2;
	}
	else if (att == 1)
	{	//获取狐狸的位置信息
		fox->get_translate(x2, y2, z2);
	}
	else if (att == 2)
	{	//同样获取机器人躯干的信息
		robot[TORSO]->get_translate(x2, y2, z2);
	}

	//设置相机的位置
	vec4 up = vec4(0, 1, 0, 0);

	if (att == 1 || att == 0)
	{ 	//全景相机的x、y、z，看的位置就是运动的物体的位置
		float x = radius * cos(upAngle * M_PI / 180.0) * sin(rotateAngle * M_PI / 180.0) + x2;
		float y = radius * sin(upAngle * M_PI / 180.0) + y2;
		float z = radius * cos(upAngle * M_PI / 180.0) * cos(rotateAngle * M_PI / 180.0) + z2;
		eye = vec4(x, y, z, 1);
		at = vec4(x2, y2, z2, 0);
	}
	else
	{ //第一视角时的相机参数，将相机置于机器人的适当位置进行观察
		eye = vec4(x2, y2 + 0.5, z2, 1);
		at = vec4(x2 + fr * sin(rotateAngle * M_PI / 180.0), y2 + 0.4, z2 + fr * cos(rotateAngle * M_PI / 180.0), 0);
	}

	mat4 viewMatrix = LookAt(eye, at, up);

	mat4 robotTransform = robot[TORSO]->getTransform();
	robot[TORSO]->get_theta(x1, y1, z1);
	robot[TORSO]->get_translate(x2, y2, z2);
	robotTransform *= Translate(vec3(x2, y2, z2)) * RotateY(y1);

	mat4 robotLeftUpperArmTransform = robotTransform //手
									  * Translate(0.5 * TORSO_WIDTH, 0.5 * TORSO_HEIGHT, 0) * RotateX(degree) * Translate(0.5 * UPPER_ARM_WIDTH, -0.5 * UPPER_ARM_HEIGHT, 0);
	mat4 robotRightUpperArmTransform = robotTransform * Translate(-0.5 * TORSO_WIDTH, 0.5 * TORSO_HEIGHT, 0) * RotateX(-degree) * Translate(-0.5 * UPPER_ARM_WIDTH, -0.5 * UPPER_ARM_HEIGHT, 0);
	mat4 robotLeftUpperLegTransform = robotTransform //腿
									  * Translate(-0.5 * TORSO_WIDTH, -0.5 * TORSO_HEIGHT, 0) * RotateX(-degree) * Translate(0.5 * UPPER_LEG_WIDTH, -0.48 * UPPER_LEG_HEIGHT, 0);
	mat4 robotRightUpperLegTransform = robotTransform * Translate(0.5 * TORSO_WIDTH, -0.5 * TORSO_HEIGHT, 0) * RotateX(degree) * Translate(-0.5 * UPPER_LEG_WIDTH, -0.48 * UPPER_LEG_HEIGHT, 0);
	robot[HEAD]->setTransform(robotTransform * Translate(0, 0.5 * TORSO_HEIGHT, 0) * Translate(0, 0.5 * HEAD_HEIGHT, 0));
	robot[LEFT_UPPER_ARM]->setTransform(robotLeftUpperArmTransform);
	robot[RIGHT_UPPER_ARM]->setTransform(robotRightUpperArmTransform);
	robot[LEFT_UPPER_LEG]->setTransform(robotLeftUpperLegTransform);
	robot[RIGHT_UPPER_LEG]->setTransform(robotRightUpperLegTransform);

	mp_->draw_meshes(viewMatrix);

	glutSwapBuffers();
};

//空闲回调都是进行重新绘制图片
void mouse(int button, int state, int x, int y)
{
	glutPostRedisplay();
}

//----------------------------------------------------------------------------
void idle(void)
{	//找到狐狸时播放游戏结束音乐，并退出程序
	float x1,y1,z1;
	fox->get_translate(x1,y1,z1);
	//cout<<"fox:"<<x1<<" "<<y1<<" "<<z1<<endl;
	float x2,y2,z2;
	robot[TORSO]->get_translate(x2,y2,z2);
	if(abs(x1-x2) < 0.3 && abs(z1-z2)<0.3)
	{
		mciSendString("close bkmusic", NULL, 0, NULL);
		mciSendString("open  backmusic/game_over.mp3 alias omusic", NULL, 0, NULL);
		mciSendString("play omusic wait", NULL, 0, NULL);
		exit(EXIT_SUCCESS);
	}
	glutPostRedisplay();
}

//----------------------------------------------------------------------------

void keyboard(unsigned char key, int mousex, int mousey)
{	//键盘回调函数
	float x, y, z;
	switch (key)
	{
	case 033: // Escape Key
		exit(EXIT_SUCCESS);
		break;
		//调整相机的位置，即相机变换
	case 'W':
	case 'w':
		if (upAngle + 1 < 180)
			upAngle += 1;
		cout << "upAngle: " << upAngle << endl;
		break;
	case 'S':
	case 's':
		if (upAngle - 1 > -90)
			upAngle -= 1;
		cout << "upAngle: " << upAngle << endl;
		break;
	case 'A':
	case 'a':
		if (att == 1 || att == 0)
			rotateAngle -= 1;
		else
			rotateAngle -= 0.5;
		cout << "rotateAngle: " << rotateAngle << endl;
		break;
	case 'D':
	case 'd':
		if (att == 0 || att == 1)
			rotateAngle += 1;
		else
			rotateAngle += 0.5;
		cout << "rotateAngle: " << rotateAngle << endl;
		break;
	case 'Q':
	case 'q':
		if (radius > 1.0)
			radius -= 0.2;
		cout << "radius: " << radius << endl;
		break;
	case 'E':
	case 'e':
		radius += 0.2;
		cout << "radius: " << radius << endl;
		break;
	case '1': //切换视角
		att = 1;	//全景视角，观察机器人
		break;
	case '0':	//全景视角，观察狐狸
		att = 0;
		break;
	case '2':	//机器人的第一视角
		att = 2;
		break;
	case '+':	//增加狐狸的尺寸
		fox->get_scale(x, y, z);
		fox->set_scale(x + 0.01, y + 0.01, z + 0.01);
		break;
	case '-':	//减小狐狸的尺寸
		fox->get_scale(x, y, z);
		fox->set_scale(x - 0.01, y - 0.01, z - 0.01);
		break;
	case 'm':
	case 'M':	//播放背景音乐
		mciSendString("open backmusic/mysong.mp3 alias bkmusic", NULL, 0, NULL);
		mciSendString("play bkmusic repeat", NULL, 0, NULL);
		break;
	case 'n':	//关闭背景音乐
	case 'N':
		mciSendString("close bkmusic", NULL, 0, NULL);
		break;

	case ' ':
		// 初始化全景相机参数
		radius = 6.80;
		rotateAngle = -92;
		upAngle = 43.0;
		at = vec4(0, 0, 0, 1);
		eye = vec4(0, 0, 0, 1);
		att = 2;
	}
	glutPostRedisplay();
}

//----------------------------------------------------------------------------
// 对于运动物体的操作
void special_key(int key, int x, int y)
{
	static bool lor = true; //判断左右手前摆
	static float x1, y1, z1, x2, y2, z2;
	switch (att)
	{
	case 0:
		switch (key)
		{
		case GLUT_KEY_UP:
			degree += lor ? 5 : -5;
			if (degree >= 30)
				lor = false;
			else if (degree <= -30)
				lor = true;
			robot[TORSO]->get_translate(x1, y1, z1);
			robot[TORSO]->get_theta(x2, y2, z2);
			robot[TORSO]->set_translate(x1 + sin(y2 * DegreesToRadians) * 0.02, y1, z1 + cos(y2 * DegreesToRadians) * 0.02);

			break;
		case GLUT_KEY_DOWN:
			degree += lor ? 5 : -5;
			if (degree >= 30)
				lor = false;
			else if (degree <= -30)
				lor = true;
			robot[TORSO]->get_translate(x1, y1, z1);
			robot[TORSO]->get_theta(x2, y2, z2);
			robot[TORSO]->set_translate(x1 - sin(y2 * DegreesToRadians) * 0.02, y1, z1 - cos(y2 * DegreesToRadians) * 0.02);
			break;
		case GLUT_KEY_LEFT:
			robot[TORSO]->get_theta(x2, y2, z2);
			robot[TORSO]->set_theta(x2, y2 + 10, z2);
			break;
		case GLUT_KEY_RIGHT:
			robot[TORSO]->get_theta(x2, y2, z2);
			robot[TORSO]->set_theta(x2, y2 - 10, z2);
			break;
		}
		cout << "degree: " << degree << endl;
		break;
	case 1: //控制狐狸进行运动
		switch (key)
		{
		case GLUT_KEY_UP:
			fox->get_translate(x1, y1, z1);
			fox->get_theta(x2, y2, z2);
			fox->set_translate(x1 + sin(y2 * DegreesToRadians) * 0.02, y1, z1 + cos(y2 * DegreesToRadians) * 0.02);
			break;
		case GLUT_KEY_DOWN:
			fox->get_translate(x1, y1, z1);
			fox->get_theta(x2, y2, z2);
			fox->set_translate(x1 - sin(y2 * DegreesToRadians) * 0.02, y1, z1 - cos(y2 * DegreesToRadians) * 0.02);
			break;
		case GLUT_KEY_LEFT:
			fox->get_theta(x2, y2, z2);
			fox->set_theta(x2, y2 + 10, z2);
			break;
		case GLUT_KEY_RIGHT:
			fox->get_theta(x2, y2, z2);
			fox->set_theta(x2, y2 - 10, z2);
			break;
		}
		break;

	case 2:	//第一视角下机器人的运动
		switch (key)
		{
		case GLUT_KEY_UP:
			degree += lor ? 2 : -2;
			if (degree >= 12)
				lor = false;
			else if (degree <= -12)
				lor = true;
			robot[TORSO]->get_translate(x1, y1, z1);
			robot[TORSO]->get_theta(x2, y2, z2);
			robot[TORSO]->set_translate(x1 + sin(y2 * DegreesToRadians) * 0.02, y1, z1 + cos(y2 * DegreesToRadians) * 0.02);

			break;
		case GLUT_KEY_DOWN:
			degree += lor ? 2 : -2;
			if (degree >= 12)
				lor = false;
			else if (degree <= -12)
				lor = true;
			robot[TORSO]->get_translate(x1, y1, z1);
			robot[TORSO]->get_theta(x2, y2, z2);
			robot[TORSO]->set_translate(x1 - sin(y2 * DegreesToRadians) * 0.02, y1, z1 - cos(y2 * DegreesToRadians) * 0.02);
			break;
		case GLUT_KEY_LEFT:
			robot[TORSO]->get_theta(x2, y2, z2);
			robot[TORSO]->set_theta(x2, y2 + 10, z2);
			rotateAngle += 10;
			break;
		case GLUT_KEY_RIGHT:
			robot[TORSO]->get_theta(x2, y2, z2);
			robot[TORSO]->set_theta(x2, y2 - 10, z2);
			rotateAngle -= 10;
			break;
		}
		break;
	}

	glutPostRedisplay();
}
void reshape(int w, int h)
{ //捕捉窗口重绘的行为
	window.width = w;
	window.height = h;
	glViewport(0, 0, window.width, window.height);
}
void createScene()
{ //场景进行绘制

	//显示模型以及纹理
	//地面
	My_Mesh *floor = new My_Mesh;
	floor->generate_floor(-0.0001, -50, -50, 50, 50, 5);
	floor->set_texture_file("texture/wood.jpg");
	floor->set_translate(0, -0.01, 0);
	floor->set_theta(0, 0, 0);
	floor->setShadow(false);
	floor->setfox(false);
	my_meshs.push_back(floor);
	mp_->add_mesh(floor);
	//建筑物的绘制
	My_Mesh *building1 = new My_Mesh;
	building1->load_obj("texture/scene/building.obj", Scale(0.2, 0.2, 0.2) * mat4(1));
	building1->set_texture_file("texture/scene/building.png");
	building1->set_translate(0, 0, 0);
	building1->set_theta(0, 0, 0);
	building1->setShadow(true);
	building1->setfox(false);
	my_meshs.push_back(building1);
	mp_->add_mesh(building1);	

	///*狐狸
	fox = new My_Mesh;
	fox->load_obj("texture/fox/fox.obj", Scale(0.005, 0.005, 0.005) * mat4(1));
	fox->set_texture_file("texture/fox/fox.png");
	fox->set_translate(10, 0, 0);
	fox->set_theta(0, 90, 0);
	fox->set_theta_step(0, 1, 0);
	fox->setShadow(true);
	fox->setfox(true);
	my_meshs.push_back(fox);
	mp_->add_mesh(fox);
}
//生成天空盒子
void createSkybox()
{
	My_Mesh *front = new My_Mesh;
	front->load_obj("texture/skybox/wall.obj", Scale(R, R, R) * mat4(1.0)); //生成盒子的前平面
	front->set_texture_file("texture/skybox/frozen_ft.tga");				//指定纹理图像文件
	front->set_translate(0, 100, R);										//平移
	front->set_theta(0, 90, 0);												//旋转轴
	front->set_theta_step(0.0, 0.0, 0.0);									//旋转速度
	front->setShadow(false);												//阴影
	front->setfox(false);													//狐狸与否
	my_meshs.push_back(front);
	mp_->add_mesh(front);

	My_Mesh *back = new My_Mesh;
	back->load_obj("texture/skybox/wall.obj", Scale(R, R, R) * mat4(1.0)); // 生成盒子的背平面
	back->set_texture_file("texture/skybox/frozen_bk.tga");				   // 指定纹理图像文件
	back->set_translate(0, 100, -R);									   // 平移
	back->set_theta(0, 270, 0);											   //旋转轴
	back->set_theta_step(0.0, 0.0, 0.0);								   //旋转速度
	back->setShadow(false);
	back->setfox(false);
	my_meshs.push_back(back);
	mp_->add_mesh(back);

	My_Mesh *right = new My_Mesh;
	right->load_obj("texture/skybox/wall.obj", Scale(R, R, R) * mat4(1.0)); // 生成盒子的右平面
	right->set_texture_file("texture/skybox/frozen_rt.tga");				// 指定纹理图像文件
	right->set_translate(R, gap, 0);										// 平移
	right->set_theta(0, 180, 0);											//旋转轴
	right->set_theta_step(0.0, 0.0, 0.0);									//旋转速度
	right->setShadow(false);
	right->setfox(false);
	my_meshs.push_back(right);
	mp_->add_mesh(right);

	My_Mesh *left = new My_Mesh;
	left->load_obj("texture/skybox/wall.obj", Scale(R, R, R) * mat4(1.0)); // 生成盒子的左平面
	left->set_texture_file("texture/skybox/frozen_lf.tga");				   // 指定纹理图像文件
	left->set_translate(-R, gap, 0);									   // 平移
	left->set_theta(0, 0, 0);											   //旋转轴
	left->set_theta_step(0.0, 0.0, 0.0);								   //旋转速度
	left->setShadow(false);
	left->setfox(false);
	my_meshs.push_back(left);
	mp_->add_mesh(left);

	My_Mesh *up = new My_Mesh;
	up->load_obj("texture/skybox/ground.obj", Scale(R, R, R) * mat4(1.0)); // 生成盒子的上平面
	up->set_texture_file("texture/skybox/frozen_up.tga");				   // 指定纹理图像文件
	up->set_translate(0, R + gap, 0);									   // 平移
	up->set_theta(180, 270, 0);											   //旋转轴
	up->set_theta_step(0.0, 0.0, 0.0);									   //旋转速度
	up->setShadow(false);
	up->setfox(false);
	my_meshs.push_back(up);
	mp_->add_mesh(up);

	My_Mesh *down = new My_Mesh;
	down->load_obj("texture/skybox/ground.obj", Scale(R, R, R) * mat4(1.0)); // 生成盒子的下平面
	down->set_texture_file("texture/skybox/frozen_dn.tga");					 // 指定纹理图像文件
	down->set_translate(0, -R + gap, 0);									 // 平移
	down->set_theta(0, 0, 0);												 //旋转轴
	down->set_theta_step(0.0, 0.0, 0.0);									 //旋转速度
	down->setShadow(false);
	down->setfox(false);
	my_meshs.push_back(down);
	mp_->add_mesh(down);
}

void createRobot()
{
	for (int i = TORSO; i < NUM_COMPONENTS; i++)
	{
		robot[i] = new My_Mesh;

		robot[i]->load_obj("texture/robot/box.obj", mat4(1.0));
		robot[i]->setShadow(true);
		robot[i]->setfox(false);
		my_meshs.push_back(robot[i]);
		mp_->add_mesh(robot[i]);
	}
	robot[TORSO]->set_texture_file("texture/steve/torso.png");
	robot[HEAD]->set_texture_file("texture/steve/head.png");
	robot[LEFT_UPPER_ARM]->set_texture_file("texture/steve/arm.png");
	robot[RIGHT_UPPER_ARM]->set_texture_file("texture/steve/arm.png");
	robot[LEFT_UPPER_LEG]->set_texture_file("texture/steve/leg.png");
	robot[RIGHT_UPPER_LEG]->set_texture_file("texture/steve/leg.png");
	robot[TORSO]->set_scale(TORSO_WIDTH, TORSO_HEIGHT, TORSO_DEPTH);
	robot[HEAD]->set_scale(HEAD_WIDTH, HEAD_HEIGHT, HEAD_DEPTH);
	robot[LEFT_UPPER_ARM]->set_scale(UPPER_ARM_WIDTH, UPPER_ARM_HEIGHT, UPPER_ARM_DEPTH);
	robot[RIGHT_UPPER_ARM]->set_scale(UPPER_ARM_WIDTH, UPPER_ARM_HEIGHT, UPPER_ARM_DEPTH);
	robot[LEFT_UPPER_LEG]->set_scale(UPPER_LEG_WIDTH, UPPER_LEG_HEIGHT, UPPER_LEG_DEPTH);
	robot[RIGHT_UPPER_LEG]->set_scale(UPPER_LEG_WIDTH, UPPER_LEG_HEIGHT, UPPER_LEG_DEPTH);
}

int main(int argc, char **argv)
{
	
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(window.width, window.height);
	glutInitContextVersion(3, 2);
	glutInitContextProfile(GLUT_CORE_PROFILE);
	glutCreateWindow("2017153017_钟辉_期末大作业");
	glewExperimental = GL_TRUE;
	glewInit();

	init();
	createSkybox();
	createScene();
	//绘制机器人
	createRobot();

	float x, y, z;
	robot[TORSO]->get_theta(x, y, z);
	robot[TORSO]->set_translate(0, 0.0, -1.0);
	robot[TORSO]->setTransform(
		Translate(0, 0.5 * TORSO_HEIGHT + UPPER_LEG_HEIGHT, 0) * RotateY(y));
	robot[TORSO]->set_theta(0, -90, 0);

	mp_->init_shaders("shaders/vshader_texture.glsl", "shaders/fshader_texture.glsl");
	mp_->setlightPos(lightPos);
	mp_->update_vertex_buffer();
	mp_->update_texture();


	
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	glutMouseFunc(mouse);
	glutIdleFunc(idle);
	glutReshapeFunc(reshape);
	glutSpecialFunc(special_key);
	glutMainLoop();
	

	for (unsigned int i = 0; i < my_meshs.size(); i++)
	{
		delete my_meshs[i];
	}
	delete mp_;

	return 0;
}
