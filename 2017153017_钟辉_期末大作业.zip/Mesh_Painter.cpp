﻿#include "Mesh_Painter.h"
#define STB_IMAGE_IMPLEMENTATION

#include <iostream>
#include "stb_image.h"

using namespace std;
Mesh_Painter::Mesh_Painter()
{
}

Mesh_Painter::~Mesh_Painter()
{
}

void Mesh_Painter::draw_meshes(mat4 viewMatrix)
{
	mat4 projMatrix = Perspective(90, 1, 0.00001, 100);
	float lx = lightPos.x;
	float ly = lightPos.y;
	float lz = lightPos.z;
	//计算投影矩阵
	mat4 shadowProjMatrix(
		-ly, 0.0, 0.0, 0.0,
		lx, 0.0, lz, 1.0,
		0.0, 0.0, -ly, 0.0,
		0.0, 0.0, 0.0, -ly);
	for (unsigned int i = 0; i < this->m_my_meshes_.size(); i++)
	{
		glUseProgram(this->program_all[i]);
		glBindVertexArray(this->vao_all[i]);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, this->textures_all[i]); //该语句必须，否则将只使用同一个纹理进行绘制

		float x, y, z;							   //对于每一个mesh针对给定的几何变换进行相应的变换
		this->m_my_meshes_[i]->get_theta(x, y, z); //旋转
		GLfloat Theta[3] = {x, y, z};
		this->m_my_meshes_[i]->get_translate(x, y, z); //平移
		vec3 translate(x, y, z);

		this->m_my_meshes_[i]->get_scale(x, y, z);
		vec3 scale(x, y, z);
		mat4 modelMatrix =
			this->m_my_meshes_[i]->getTransform() * Translate(translate) * RotateZ(Theta[2]) * RotateY(Theta[1]) * RotateX(Theta[0]) * Scale(scale);

		glUniformMatrix4fv(viewMatrix_all[i], 1, GL_TRUE, viewMatrix);
		glUniformMatrix4fv(projMatrix_all[i], 1, GL_TRUE, projMatrix);
		glUniform3fv(lightPos_all[i], 1, lightPos);
		if (this->m_my_meshes_[i]->isShadow())
		{ // 将投影矩阵以及模式矩阵传给着色器
			glUniformMatrix4fv(modelMatrix_all[i], 1, GL_TRUE, shadowProjMatrix * modelMatrix);
			glUniform1i(is_shadow_all[i], 1);
			glDrawArrays(GL_TRIANGLES, 0, this->m_my_meshes_[i]->num_faces() * 3);
		}
		glUniformMatrix4fv(modelMatrix_all[i], 1, GL_TRUE, modelMatrix);
		glUniform1i(is_shadow_all[i], 0);
		glDrawArrays(GL_TRIANGLES, 0, this->m_my_meshes_[i]->num_faces() * 3);
		glUseProgram(0);
	}
};

void Mesh_Painter::update_texture()
{
	this->textures_all.clear();

	for (unsigned int i = 0; i < this->m_my_meshes_.size(); i++)
	{
		GLuint textures;

		// 调用stb_image生成纹理
		glGenTextures(1, &textures);

		load_texture_STBImage(this->m_my_meshes_[i]->get_texture_file(), textures);

		//指定最大最小过滤方法，此两行代码必须添加，否则将无法显示纹理
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

		// 将生成的纹理传给shader
		glUniform1i(glGetUniformLocation(this->program_all[i], "texture"), 0);
		this->textures_all.push_back(textures);
	}
};

void Mesh_Painter::load_texture_STBImage(std::string file_name, GLuint &m_texName)
{
	int width, height, channels = 0;
	unsigned char *pixels = NULL;
	stbi_set_flip_vertically_on_load(true);
	pixels = stbi_load(file_name.c_str(), &width, &height, &channels, 0);

	// 调整行对齐格式
	if (width * channels % 4 != 0)
		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	GLenum format = GL_RGB;
	// 设置通道格式
	switch (channels)
	{
	case 1:
		format = GL_RED;
		break;
	case 3:
		format = GL_RGB;
		break;
	case 4:
		format = GL_RGBA;
		break;
	default:
		format = GL_RGB;
		break;
	}

	// 绑定纹理对象
	glBindTexture(GL_TEXTURE_2D, m_texName);

	// 指定纹理的放大，缩小滤波，使用线性方式，即当图片放大的时候插值方式
	// 将图片的rgb数据上传给opengl
	glTexImage2D(
		GL_TEXTURE_2D,	// 指定目标纹理，这个值必须是GL_TEXTURE_2D
		0,				  // 执行细节级别，0是最基本的图像级别，n表示第N级贴图细化级别
		format,			  // 纹理数据的颜色格式(GPU显存)
		width,			  // 宽度。早期的显卡不支持不规则的纹理，则宽度和高度必须是2^n
		height,			  // 高度。早期的显卡不支持不规则的纹理，则宽度和高度必须是2^n
		0,				  // 指定边框的宽度。必须为0
		format,			  // 像素数据的颜色格式(CPU内存)
		GL_UNSIGNED_BYTE, // 指定像素数据的数据类型
		pixels			  // 指定内存中指向图像数据的指针
	);

	// 生成多级渐远纹理，多消耗1/3的显存，较小分辨率时获得更好的效果
	// glGenerateMipmap(GL_TEXTURE_2D);

	// 指定插值方法
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	// 恢复初始对齐格式
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	// 释放图形内存
	stbi_image_free(pixels);
};

void Mesh_Painter::update_vertex_buffer()
{
	this->vao_all.clear();
	this->buffer_all.clear();
	this->vPosition_all.clear();
	this->vColor_all.clear();
	this->vTexCoord_all.clear();
	this->vNormal_all.clear();

	for (unsigned int m_i = 0; m_i < this->m_my_meshes_.size(); m_i++)
	{
		//在这里添加代码实现顶点坐标，法线，颜色，纹理坐标到shader的映射
		int num_face = this->m_my_meshes_[m_i]->num_faces();
		int num_vertex = this->m_my_meshes_[m_i]->num_vertices();
		const VertexList &vertex_list = this->m_my_meshes_[m_i]->get_vertices();
		const NormalList &normal_list = this->m_my_meshes_[m_i]->get_normals();
		const FaceList &face_list = this->m_my_meshes_[m_i]->get_faces();
		const STLVectorf &color_list = this->m_my_meshes_[m_i]->get_colors();
		const VtList &vt_list = this->m_my_meshes_[m_i]->get_vts();

		// Create a vertex array object
		GLuint vao;
		glGenVertexArrays(1, &vao);
		glBindVertexArray(vao);

		GLuint buffer;
		glGenBuffers(1, &buffer);
		glBindBuffer(GL_ARRAY_BUFFER, buffer);
		glBufferData(GL_ARRAY_BUFFER,
					 sizeof(vec3) * num_face * 3 + sizeof(vec3) * num_face * 3 + sizeof(vec3) * num_face * 3 + sizeof(vec2) * num_face * 3,
					 NULL, GL_STATIC_DRAW);
		//获得足够的空间存储坐标，颜色，法线以及纹理坐标等等
		// Specify an offset to keep track of where we're placing data in our
		//   vertex array buffer.  We'll use the same technique when we
		//   associate the offsets with vertex attribute pointers.

		vec3 *points = new vec3[num_face * 3];

		for (int i = 0; i < num_face; i++)
		{
			int index = face_list[9 * i];
			points[3 * i] = vec3(
				(vertex_list[index * 3 + 0]),
				(vertex_list[index * 3 + 1]),
				(vertex_list[index * 3 + 2]));

			index = face_list[9 * i + 3];
			points[3 * i + 1] = vec3(
				(vertex_list[index * 3 + 0]),
				(vertex_list[index * 3 + 1]),
				(vertex_list[index * 3 + 2]));

			index = face_list[9 * i + 6];
			points[3 * i + 2] = vec3(
				(vertex_list[index * 3 + 0]),
				(vertex_list[index * 3 + 1]),
				(vertex_list[index * 3 + 2]));
		}
		GLintptr offset = 0;
		glBufferSubData(GL_ARRAY_BUFFER, offset, sizeof(vec3) * num_face * 3, points);
		//顶点坐标传给shader
		offset += sizeof(vec3) * num_face * 3;
		delete[] points;
		/************************************************************************/
		/*                                                                      */
		/************************************************************************/
		points = new vec3[num_face * 3];
		for (int i = 0; i < num_face; i++)
		{
			int index = face_list[9 * i + 2];
			points[3 * i] = vec3(
				(normal_list[index * 3 + 0]),
				(normal_list[index * 3 + 1]),
				(normal_list[index * 3 + 2]));

			index = face_list[9 * i + 5];
			points[3 * i + 1] = vec3(
				(normal_list[index * 3 + 0]),
				(normal_list[index * 3 + 1]),
				(normal_list[index * 3 + 2]));

			index = face_list[9 * i + 8];
			points[3 * i + 2] = vec3(
				(normal_list[index * 3 + 0]),
				(normal_list[index * 3 + 1]),
				(normal_list[index * 3 + 2]));
		}
		glBufferSubData(GL_ARRAY_BUFFER, offset, sizeof(vec3) * num_face * 3, points);
		offset += sizeof(vec3) * num_face * 3;
		delete[] points;
		//法线传给shader

		/************************************************************************/
		/*                                                                      */
		/************************************************************************/
		points = new vec3[num_face * 3];
		for (int i = 0; i < num_face; i++)
		{
			int index = face_list[9 * i + 2];
			points[3 * i] = vec3(
				(color_list[index * 3 + 0]),
				(color_list[index * 3 + 1]),
				(color_list[index * 3 + 2]));

			index = face_list[9 * i + 5];
			points[3 * i + 1] = vec3(
				(color_list[index * 3 + 0]),
				(color_list[index * 3 + 1]),
				(color_list[index * 3 + 2]));

			index = face_list[9 * i + 8];
			points[3 * i + 2] = vec3(
				(color_list[index * 3 + 0]),
				(color_list[index * 3 + 1]),
				(color_list[index * 3 + 2]));
		}
		glBufferSubData(GL_ARRAY_BUFFER, offset, sizeof(vec3) * num_face * 3, points);
		//颜色传给shader
		offset += sizeof(vec3) * num_face * 3;
		delete[] points;

		/************************************************************************/
		/*                                                                      */
		/************************************************************************/
		vec2 *points_2 = new vec2[num_face * 3];
		for (int i = 0; i < num_face; i++)
		{
			//points_2[i * 3] = vec2(vt_list[i * 6 + 0], vt_list[i * 6 + 1]);
			//points_2[i * 3 + 1] = vec2(vt_list[i * 6 + 2], vt_list[i * 6 + 3]);
			//points_2[i * 3 + 2] = vec2(vt_list[i * 6 + 4], vt_list[i * 6 + 5]);
			int index = face_list[9 * i + 1];
			points_2[3 * i] = vec2(
				(vt_list[index * 3 + 0]),
				(vt_list[index * 3 + 1])
				//(vt_list[index * 3 + 2])
			);

			index = face_list[9 * i + 4];
			points_2[3 * i + 1] = vec2(
				(vt_list[index * 3 + 0]),
				(vt_list[index * 3 + 1])
				//(vt_list[index * 3 + 2])
			);

			index = face_list[9 * i + 7];
			points_2[3 * i + 2] = vec2(
				(vt_list[index * 3 + 0]),
				(vt_list[index * 3 + 1])
				//(vt_list[index * 3 + 2])
			);
		}
		glBufferSubData(GL_ARRAY_BUFFER, offset, sizeof(vec2) * num_face * 3, points_2);
		offset += sizeof(vec2) * num_face * 3;
		delete points_2;
		//纹理坐标传给shader
		/************************************************************************/
		/*                                                                      */
		/************************************************************************/

		// Load shaders and use the resulting shader program

		// set up vertex arrays
		offset = 0;
		GLuint vPosition;
		vPosition = glGetAttribLocation(this->program_all[m_i], "vPosition");
		glEnableVertexAttribArray(vPosition);
		glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, 0,
							  BUFFER_OFFSET(offset));
		offset += sizeof(vec3) * num_face * 3;
		//指定vPosition在shader中使用时的位置

		GLuint vNormal;
		vNormal = glGetAttribLocation(this->program_all[m_i], "vNormal");
		glEnableVertexAttribArray(vNormal);
		glVertexAttribPointer(vNormal, 3, GL_FLOAT, GL_FALSE, 0,
							  BUFFER_OFFSET(offset));
		offset += sizeof(vec3) * num_face * 3;
		//指定vNormal在shader中使用时的位置

		GLuint vColor;
		vColor = glGetAttribLocation(this->program_all[m_i], "vColor");
		glEnableVertexAttribArray(vColor);
		glVertexAttribPointer(vColor, 3, GL_FLOAT, GL_FALSE, 0,
							  BUFFER_OFFSET(offset));
		offset += sizeof(vec3) * num_face * 3;
		//指定vColor在shader中使用时的位置

		GLuint vTexCoord;
		vTexCoord = glGetAttribLocation(this->program_all[m_i], "vTexCoord");
		glEnableVertexAttribArray(vTexCoord);
		glVertexAttribPointer(vTexCoord, 2, GL_FLOAT, GL_FALSE, 0,
							  BUFFER_OFFSET(offset));
		//指定vTexCoord在shader中使用时的位置

		/************************************************************************/
		/*                                                                      */
		/************************************************************************/

		this->vao_all.push_back(vao);
		this->buffer_all.push_back(buffer);
		this->vPosition_all.push_back(vPosition);
		this->vColor_all.push_back(vColor);
		this->vTexCoord_all.push_back(vTexCoord);
		this->vNormal_all.push_back(vNormal);
	}
};
void Mesh_Painter::init_shaders(std::string vs, std::string fs)
{
	this->program_all.clear();
	this->theta_all.clear();
	this->trans_all.clear();

	GLuint program = InitShader(vs.c_str(), fs.c_str());

	for (unsigned int i = 0; i < this->m_my_meshes_.size(); i++)
	{
		GLuint program = InitShader(vs.c_str(), fs.c_str());
		glUseProgram(program);
		this->program_all.push_back(program);
		//将需要执行的几何变换都传给相对应的shader
		GLuint theta = glGetUniformLocation(program, "theta");
		GLuint trans = glGetUniformLocation(program, "translation");
		GLuint modelMatrix = glGetUniformLocation(program, "modelMatrix");
		GLuint viewMatrix = glGetUniformLocation(program, "viewMatrix");
		GLuint projMatrix = glGetUniformLocation(program, "projMatrix");
		GLuint isShadow = glGetUniformLocation(program, "is_shadow");
		GLuint lightPos = glGetUniformLocation(program, "lightPos");

		theta_all.push_back(theta);
		trans_all.push_back(trans);
		viewMatrix_all.push_back(viewMatrix);
		modelMatrix_all.push_back(modelMatrix);
		projMatrix_all.push_back(projMatrix);
		is_shadow_all.push_back(isShadow);
		lightPos_all.push_back(lightPos);
	}
};
void Mesh_Painter::setlightPos(vec3 lightPos)
{
	this->lightPos = lightPos;
}
void Mesh_Painter::add_mesh(My_Mesh *m)
{
	this->m_my_meshes_.push_back(m);
};
void Mesh_Painter::clear_mehs()
{ //将所有元素进行清空
	this->m_my_meshes_.clear();

	this->textures_all.clear();
	this->program_all.clear();
	this->vao_all.clear();
	this->buffer_all.clear();
	this->vPosition_all.clear();
	this->vColor_all.clear();
	this->vTexCoord_all.clear();
	this->vNormal_all.clear();
	this->viewMatrix_all.clear();
	this->modelMatrix_all.clear();
	this->projMatrix_all.clear();
	this->is_shadow_all.clear();
};
